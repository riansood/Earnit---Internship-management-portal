package dao;

import java.sql.*;
import model.Employee;
import model.Student;

public class DatabaseConnection {
    private static String host = "bronto.ewi.utwente.nl";
    private static String dbName = "dab_di23242b_133";
    private static String url = "jdbc:postgresql://" + host + ":5432/" + dbName;
    private static String username = "dab_di23242b_133";
    private static String password = "snCN+GM/3fkdyUkv";
    /**
     * Loads the PostgreSQL JDBC driver.
     * <p>
     * This method attempts to load the driver class for PostgreSQL database connectivity.
     * If the driver class is not found, it prints an error message to the standard error stream.
     * </p>
     */
    public static void loadDriver() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println("Error loading driver: " + cnfe);
        }
    }

    /**
     * Establishes and returns a connection to the PostgreSQL database.
     * <p>
     * This method uses the JDBC {@code DriverManager} to obtain a connection to the specified database
     * using the provided URL, username, and password.
     * If the connection fails, it prints an error message to the standard error stream.
     * </p>
     *
     * @return a {@code Connection} object if the connection is successful; {@code null} otherwise
     */
    public static Connection getConnection() {
        Connection connection = null;
        try {
            System.out.println(url);
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException sqle) {
            System.err.println("Error connecting: " + sqle);
        }
        return connection;
    }

    /**
     * The main method that executes SQL statements to modify the database schema.
     * <p>
     * This method first loads the PostgreSQL JDBC driver and then attempts to establish a connection to the database.
     * If the connection is successful, it creates a {@code Statement} object and executes SQL statements
     * to alter the "Earnings" table by adding new columns.
     * </p>
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        loadDriver();
        try (Connection connection = getConnection()) {
            if (connection != null) {
                Statement statement = connection.createStatement();
                statement.execute("ALTER TABLE Earnings ADD VAT FLOAT;");
                statement.execute("ALTER TABLE Earnings ADD personalExpVAT FLOAT;");
            } else {
                System.err.println("Failed to establish connection.");
            }
        } catch (SQLException sqle) {
            System.err.println("SQL error: " + sqle);
        }
    }
    // loadDriver();
    // Connection connection = getConnection();
    // if (connection != null) {
    // try {
    // Statement statement = connection.createStatement();
    //
    // //Create User table
    // // Add unique constraint to Earnings table
    // // statement.execute("ALTER TABLE Earnings ADD CONSTRAINT unique_student_id UNIQUE (student_id);");
    //
    //// // Add foreign key constraint to Student table
    //// statement.execute("ALTER TABLE Student " +
    //// "ADD password VARCHAR(50);");
    ////
    //// // Add foreign key constraint to Employment_form
    //// statement.execute("ALTER TABLE Employee " +
    //// "ADD password VARCHAR(50);");
    //
    // String[] sqlStatements = {
    // "ALTER TABLE Employment_form ADD companyName VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD companyAddress VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD businessStartDate DATE",
    // "ALTER TABLE Employment_form ADD businessPhoneNumber BIGINT",
    // "ALTER TABLE Employment_form ADD businessWebsite VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD studentName VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD studentAddress VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD dateOfBirth DATE",
    // "ALTER TABLE Employment_form ADD BSN BIGINT",
    // "ALTER TABLE Employment_form ADD natureOfBusiness VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD earningsFirstYear FLOAT",
    // "ALTER TABLE Employment_form ADD companySpendings FLOAT",
    // "ALTER TABLE Employment_form ADD noOfEmployers INT",
    // "ALTER TABLE Employment_form ADD initialsAndSurname VARCHAR(255)",
    // "ALTER TABLE Employment_form ADD dateOfSignature DATE",
    // "ALTER TABLE Employment_form ADD studentPhoneNumber BIGINT"
    // };
    //
    //
    // for (String sql : sqlStatements) {
    // statement.execute(sql);
    // System.out.println("Successfully executed: " + sql);
    // }
    //
    // } catch (SQLException e) {
    // throw new RuntimeException(e);
    // }
    // }}}
    //

    // if (connection != null) {
    // try {
    // Statement statement = connection.createStatement();
    //
    //// // Create Student table
    //// statement.execute("CREATE TABLE Student (" +
    //// " email VARCHAR(50) PRIMARY KEY," +
    //// " name VARCHAR(50)," +
    //// " address VARCHAR(50)," +
    //// " BTW_number VARCHAR(50), \n+ +
    // ");\n");
    ////
    ////
    //// statement.execute("CREATE TABLE Employee (\n" +
    //// " email VARCHAR(50) PRIMARY KEY,\n" +
    //// ");\n");
    ////
    //// statement.execute("CREATE TABLE Tax (\n" +
    //// " tax_id VARCHAR(50) PRIMARY KEY,\n" +
    //// " tax_amount DECIMAL(10, 2),\n" +
    //// " isPaid BOOLEAN\n" +
    //// ");\n" );
    ////
    //// statement.execute("CREATE TABLE Employment_form (\n" +
    //// " form_id VARCHAR(50) PRIMARY KEY,\n" +
    //// " details JSON,\n" +
    //// " student_id VARCHAR(50) NOT NULL,\n" +
    //// " FOREIGN KEY (student_id) REFERENCES Student (email),\n" +
    //// " UNIQUE (student_id)\n" +
    //// ");\n");
    ////
    //// statement.execute( "CREATE TABLE Comment (\n" +
    //// " comment_id VARCHAR(50) PRIMARY KEY,\n" +
    //// " message TEXT,\n" +
    //// " isAccepted BOOLEAN,\n" +
    //// " employee_id VARCHAR(50) NOT NULL,\n" +
    //// " form_id VARCHAR(50) NOT NULL,\n" +
    //// " FOREIGN KEY (employee_id) REFERENCES Employee (email),\n" +
    //// " FOREIGN KEY (form_id) REFERENCES Employment_form (form_id)\n" +
    //// ");\n");
    ////
    //// statement.execute("CREATE TABLE Earnings (\n" +
    //// " earning_id VARCHAR(50) PRIMARY KEY,\n" +
    //// " date DATE,\n" +
    //// " earning_amount DECIMAL(10, 2),\n" +
    //// " student_id VARCHAR(50) NOT NULL,\n" +
    //// " tax_id VARCHAR(50) NOT NULL,\n" +
    //// " FOREIGN KEY (student_id) REFERENCES Student (email),\n" +
    //// " FOREIGN KEY (tax_id) REFERENCES Tax (tax_id)\n" +
    //// ");");
    // // Add CHECK constraints without subqueries
    // //Add unique constraint to Earnings table
    // statement.execute("ALTER TABLE Earnings ADD CONSTRAINT unique_student_id UNIQUE (student_id);");
    //
    // // Add foreign key constraint to Student table
    // statement.execute("ALTER TABLE Student " +
    // "ADD CONSTRAINT student_in_earnings FOREIGN KEY (email) REFERENCES Earnings(student_id);");
    //
    // // Add foreign key constraint to Employment_form
    // statement.execute("ALTER TABLE Employment_form " +
    // "ADD CONSTRAINT student_in_employment_form FOREIGN KEY (student_id) REFERENCES Student(email);");
    //
    //
    //
    // System.out.println("Tables constraint created successfully.");
    // } catch (SQLException sqle) {
    // System.err.println("SQL error: " + sqle);
    // } finally {
    // try {
    // connection.close();
    // } catch (SQLException sqle) {
    // System.err.println("Error closing connection: " + sqle);
    // }
    // }
    // }
    // }
    //}
}