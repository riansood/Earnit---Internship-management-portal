package Routes;

import dao.VATformDao;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import java.io.IOException;
import java.sql.SQLException;
import model.VATform;
import org.apache.pdfbox.pdmodel.PDDocument;
import util.SendEmailSSL;
import util.VATformPDFgenerator;

/**
 * This class handles the REST API endpoints for VAT form-related operations.
 * It includes functionalities for creating a VAT form and (commented-out) methods for updating different fields of the VAT form.
 */
@Path("/vatForm")
public class VATformRoutes {
    /**
     * Creates a new VAT form for the currently logged-in user.
     * The student's email is retrieved from the session and set as the student ID in the VAT form.
     *
     * @param form The VATform object containing the details of the VAT form to be created.
     * @param request The HttpServletRequest object to access the current session and obtain the logged-in user's email.
     * @return The created VATform object.
     * @throws SQLException If there is a database access error.
     * @throws IOException If there is an error in handling the VAT form file.
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public VATform createVATform(VATform form, @Context HttpServletRequest request) throws SQLException, IOException {
        HttpSession session = request.getSession(false);
        form.setStudent_id((String) session.getAttribute("email"));
        //System.out.println(session.getAttribute("email"));
        SendEmailSSL.sendApplicationEmail((String) session.getAttribute("email"));
        return VATformDao.INSTANCE.create(form);
    }

//    @GET
//    @Path("/{student_id}")
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform getVATform(@PathParam("student_id") String studentId) {
//        VATform vatform = VATformDao.INSTANCE.getVATform(studentId);
//        if (vatform != null) {
//            return vatform;
//        } else {
//            throw new WebApplicationException(
//                    Response.status(Response.Status.NOT_FOUND).entity("{\"error\": \"VATform not found\"}").build());
//        }
//    }
//
//    @PUT
//    @Path("/updateCompanyAddress")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateCompanyAddress(@QueryParam("email") String email, @QueryParam("companyAddress") String companyAddress) {
//        VATformDao.INSTANCE.updateCompanyAddress(email, companyAddress);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateBusinessStartDate")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateBusinessStartDate(@QueryParam("email") String email, @QueryParam("businessStartDate") String businessStartDate) {
//        VATformDao.INSTANCE.updateBusinessStartDate(email, businessStartDate);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateBusinessPhoneNumber")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateBusinessPhoneNumber(@QueryParam("email") String email, @QueryParam("businessPhoneNumber") long businessPhoneNumber) {
//        VATformDao.INSTANCE.updateBusinessPhoneNumber(email, businessPhoneNumber);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateBusinessWebsite")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateBusinessWebsite(@QueryParam("email") String email, @QueryParam("businessWebsite") String businessWebsite) {
//        VATformDao.INSTANCE.updateBusinessWebsite(email, businessWebsite);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateStudentName")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateStudentName(@QueryParam("email") String email, @QueryParam("studentName") String studentName) {
//        VATformDao.INSTANCE.updateStudentName(email, studentName);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateStudentAddress")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateStudentAddress(@QueryParam("email") String email, @QueryParam("studentAddress") String studentAddress) {
//        VATformDao.INSTANCE.updateStudentAddress(email, studentAddress);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateDateOfBirth")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateDateOfBirth(@QueryParam("email") String email, @QueryParam("dateOfBirth") String dateOfBirth) {
//        VATformDao.INSTANCE.updateDateOfBirth(email, dateOfBirth);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateBSN")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateBSN(@QueryParam("email") String email, @QueryParam("BSN") long BSN) {
//        VATformDao.INSTANCE.updateBSN(email, BSN);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateNatureOfBusiness")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateNatureOfBusiness(@QueryParam("email") String email, @QueryParam("natureOfBusiness") String natureOfBusiness) {
//        VATformDao.INSTANCE.updateNatureOfBusiness(email, natureOfBusiness);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateEarningsFirstYear")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateEarningsFirstYear(@QueryParam("email") String email, @QueryParam("earningsFirstYear") float earningsFirstYear) {
//        VATformDao.INSTANCE.updateEarningsFirstYear(email, earningsFirstYear);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateCompanySpendings")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateCompanySpendings(@QueryParam("email") String email, @QueryParam("companySpendings") float companySpendings) {
//        VATformDao.INSTANCE.updateCompanySpendings(email, companySpendings);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateNoOfEmployers")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateNoOfEmployers(@QueryParam("email") String email, @QueryParam("noOfEmployers") int noOfEmployers) {
//        VATformDao.INSTANCE.updateNoOfEmployers(email, noOfEmployers);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateInitialsAndSurname")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateInitialsAndSurname(@QueryParam("email") String email, @QueryParam("initialsAndSurname") String initialsAndSurname) {
//        VATformDao.INSTANCE.updateInitialsAndSurname(email, initialsAndSurname);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateDateOfSignature")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateDateOfSignature(@QueryParam("email") String email, @QueryParam("dateOfSignature") String dateOfSignature) {
//        VATformDao.INSTANCE.updateDateOfSignature(email, dateOfSignature);
//        return VATformDao.INSTANCE.getVATform(email);
//    }
//
//    @PUT
//    @Path("/updateStudentPhoneNumber")
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Produces(MediaType.APPLICATION_JSON)
//    public VATform updateStudentPhoneNumber(@QueryParam("email") String email, @QueryParam("studentPhoneNumber") long studentPhoneNumber) {
//        VATformDao.INSTANCE.updateStudentPhoneNumber(email, studentPhoneNumber);
//        return VATformDao.INSTANCE.getVATform(email);
//    }










}
