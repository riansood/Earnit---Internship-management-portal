package model;

public class Employee{
    public String email;
    public String password;
    public String salt;

public Employee(){}
    public Employee(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password; }


}
