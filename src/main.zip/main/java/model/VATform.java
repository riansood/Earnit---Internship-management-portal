package model;

public class VATform {
    public Integer form_id;
    public String student_id;
    public String companyName;
    public String companyAddress;
    public String businessStartDate;
    public String businessPhoneNumber;
    public String businessWebsite;
    public String studentName;
    public String studentAddress;
    public String dateOfBirth;
    public String BSN;
    public String natureOfBusiness;
    public Double earningsFirstYear;
    public Double companySpendings;
    public String noOfEmployers;
    public String initialsAndSurname;
    public String dateOfSignature;
    public String studentPhoneNumber;
    public String signatureBase64;

    public VATform(Integer form_id, String student_id, String companyName, String companyAddress, String businessStartDate, String businessPhoneNumber, String businessWebsite, String studentName, String studentAddress, String dateOfBirth, String BSN, String natureOfBusiness, Double earningsFirstYear, Double companySpendings, String noOfEmployers, String initialsAndSurname, String dateOfSignature, String studentPhoneNumber, String signatureBase64) {
        this.form_id=form_id;
        this.student_id=student_id;
        this.companyName = companyName;
        this.companyAddress = companyAddress;
        this.businessStartDate = businessStartDate;
        this.businessPhoneNumber = businessPhoneNumber;
        this.businessWebsite = businessWebsite;
        this.studentName = studentName;
        this.studentAddress = studentAddress;
        this.dateOfBirth = dateOfBirth;
        this.BSN = BSN;
        this.natureOfBusiness = natureOfBusiness;
        this.earningsFirstYear = earningsFirstYear;
        this.companySpendings = companySpendings;
        this.noOfEmployers = noOfEmployers;
        this.initialsAndSurname = initialsAndSurname;
        this.dateOfSignature = dateOfSignature;
        this.studentPhoneNumber = studentPhoneNumber;
        this.signatureBase64 = signatureBase64;
    }

    public String getSignatureBase64() {
        return signatureBase64;
    }

    public void setSignatureBase64(String signatureBase64) {
        this.signatureBase64 = signatureBase64;
    }

    public String extractStreetName(String address) {
        String[] parts = address.split(" ");
        StringBuilder streetNameBuilder = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].matches("\\d+")) {
                break;
            }
            if (i > 0) {
                streetNameBuilder.append(" ");
            }
            streetNameBuilder.append(parts[i]);
        }
        return streetNameBuilder.toString();
    }

    public String extractHouseNumber(String address) {
        String[] parts = address.split(" ");
        for (String part : parts) {
            if (part.matches("\\d+")) {
                return part;
            }
        }
        return "";
    }

    public String extractAddition(String address) {
        String[] parts = address.split(" ");
        boolean foundHouseNumber = false;
        for (String part : parts) {
            if (foundHouseNumber) {
                if (!part.matches("\\d+")) {
                    return part;
                } else {
                    foundHouseNumber = false;  // if the addition is a number, skip it
                }
            }
            if (part.matches("\\d+")) {
                foundHouseNumber = true;
            }
        }
        return "";
    }

    public String extractPostalCode(String address) {
        String[] parts = address.split(" ");
        if (parts.length >= 2) {
            return parts[parts.length - 2];
        }
        return "";
    }

    public String extractCity(String address) {
        String[] parts = address.split(" ");
        if (parts.length >= 1) {
            return parts[parts.length - 1];
        }
        return "";
    }



    public String getDay(String date) {
        return date.split("-")[0];
    }

    public String getMonth(String date) {
        return date.split("-")[1];
    }

    public String getYear(String date) {
        return date.split("-")[2];
    }

    public Integer getForm_id() {
        return form_id;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getBusinessStartDate() {
        return businessStartDate;
    }

    public void setBusinessStartDate(String businessStartDate) {
        this.businessStartDate = businessStartDate;
    }

    public VATform() {

    }

    public String getBusinessPhoneNumber() {
        return businessPhoneNumber;
    }

    public void setBusinessPhoneNumber(String businessPhoneNumber) {
        this.businessPhoneNumber = businessPhoneNumber;
    }

    public String getBusinessWebsite() {
        return businessWebsite;
    }

    public void setBusinessWebsite(String businessWebsite) {
        this.businessWebsite = businessWebsite;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentAddress() {
        return studentAddress;
    }

    public void setStudentAddress(String studentAddress) {
        this.studentAddress = studentAddress;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getBSN() {
        return BSN;
    }

    public void setBSN(String BSN) {
        this.BSN = BSN;
    }

    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    public Double getEarningsFirstYear() {
        return earningsFirstYear;
    }

    public void setEarningsFirstYear(Double earningsFirstYear) {
        this.earningsFirstYear = earningsFirstYear;
    }

    public Double getCompanySpendings() {
        return companySpendings;
    }

    public void setCompanySpendings(Double companySpendings) {
        this.companySpendings = companySpendings;
    }

    public String getNoOfEmployers() {
        return noOfEmployers;
    }

    public void setNoOfEmployers(String noOfEmployers) {
        this.noOfEmployers = noOfEmployers;
    }

    public String getInitialsAndSurname() {
        return initialsAndSurname;
    }

    public void setInitialsAndSurname(String initialsAndSurname) {
        this.initialsAndSurname = initialsAndSurname;
    }

    public String getDateOfSignature() {
        return dateOfSignature;
    }

    public void setDateOfSignature(String dateOfSignature) {
        this.dateOfSignature = dateOfSignature;
    }

    public String getStudentPhoneNumber() {
        return studentPhoneNumber;
    }

    public void setStudentPhoneNumber(String studentPhoneNumber) {
        this.studentPhoneNumber = studentPhoneNumber;
    }

    public String toString() {
        return "VATform{" +
                "form_id=" + form_id +
                ", student_id='" + student_id + '\'' +
                ", companyName='" + companyName + '\'' +
                ", companyAddress='" + companyAddress + '\'' +
                ", businessStartDate='" + businessStartDate + '\'' +
                ", businessPhoneNumber='" + businessPhoneNumber + '\'' +
                ", businessWebsite='" + businessWebsite + '\'' +
                ", studentName='" + studentName + '\'' +
                ", studentAddress='" + studentAddress + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", BSN='" + BSN + '\'' +
                ", natureOfBusiness='" + natureOfBusiness + '\'' +
                ", earningsFirstYear=" + earningsFirstYear +
                ", companySpendings=" + companySpendings +
                ", noOfEmployers=" + noOfEmployers +
                ", initialsAndSurname='" + initialsAndSurname + '\'' +
                ", dateOfSignature='" + dateOfSignature + '\'' +
                ", studentPhoneNumber='" + studentPhoneNumber + '\'' +
                '}';
    }
}
